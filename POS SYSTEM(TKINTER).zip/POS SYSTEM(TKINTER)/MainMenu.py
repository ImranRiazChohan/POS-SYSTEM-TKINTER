import tkinter as tk
from tkinter import ttk

class Main_Menu:
    def __init__(self,root):
        self.root=root
        # BottomButtonsForm
        self.Bottom_form=ttk.Frame(self.root,height=70,width=600,relief="raise")
        self.Bottom_form.grid(column=1,row=1,columnspan=3,rowspan=3)
        #       RecipetForm
        self.Reciept_form = ttk.Frame(self.root, height=520, width=300, relief="raise")
        self.Reciept_form.grid(column=1, row=0, padx=30, pady=50)
        #       InsertButtonsForm
        self.Insert_button_form = ttk.Frame(self.root, height=520, width=300)
        self.Insert_button_form.grid(column=2, row=0)
        #       TabControlFrom
        # self.TabFrame=ttk.Frame(self.root,height=520,width=300)
        self.tab_control = ttk.Notebook(self.root)
        self.DealTab = ttk.Frame(self.tab_control)
        self.DrinksTab = ttk.Frame(self.tab_control)
        self.PastaTab = ttk.Frame(self.tab_control)
        self.SaladTab = ttk.Frame(self.tab_control)
        self.MenuTab = ttk.Frame(self.tab_control)
        self.PizzaTab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.MenuTab, text="Menu")
        self.tab_control.add(self.DealTab, text="Deals")
        self.tab_control.add(self.DrinksTab, text="Drink")
        self.tab_control.add(self.PastaTab, text="Pasta")
        self.tab_control.add(self.SaladTab, text="Salad")
        self.tab_control.add(self.PizzaTab, text="Pizza")
        self.tab_control.grid(column=0,row=0)

#        Deals Buttons

        self.deal1=ttk.Button(self.DealTab, text="Deal1")
        self.deal1.grid(column=0, row=0, padx=20, pady=20)
        self.deal12=ttk.Button(self.DealTab, text="Deal2").grid(column=0, row=1, padx=20, pady=20)
        self.deal13=ttk.Button(self.DealTab, text="Deal3").grid(column=1, row=0, padx=20, pady=20)
        self.deal14=ttk.Button(self.DealTab, text="Deal3").grid(column=1, row=0, padx=20, pady=20)
        self.deal15=ttk.Button(self.DealTab, text="Deal3").grid(column=2, row=0, padx=20, pady=20)

#       Drinks Buttons

        self.sevenUp=ttk.Button(self.DrinksTab, text="7Up").grid(column=0, row=0, padx=20, pady=20)
        self.Pepsi=ttk.Button(self.DrinksTab, text="Pepsi").grid(column=0, row=0, padx=20, pady=20)
        self.Dew=ttk.Button(self.DrinksTab, text="DEW").grid(column=0, row=1, padx=20, pady=20)
        self.AquaFina=ttk.Button(self.DrinksTab, text="AquaFina").grid(column=1, row=0, padx=20, pady=20)
        self.Sprite=ttk.Button(self.DrinksTab, text="Sprite").grid(column=1, row=0, padx=20, pady=20)
        self.Marinda=ttk.Button(self.DrinksTab, text="Marinda").grid(column=2, row=0, padx=20, pady=20)

#       Pasta Buttons

        self.Pasta1=ttk.Button(self.PastaTab, text="Lasagane").grid(column=0, row=0, padx=20, pady=20)
        self.Pasta2=ttk.Button(self.PastaTab, text="Pasta").grid(column=1, row=0, padx=20, pady=20)

#       Pizza Buttons

        self.Pizza1=ttk.Button(self.PizzaTab, text="ChickenFajita").grid(column=0, row=0, padx=20, pady=20)
        self.Pizza2=ttk.Button(self.PizzaTab, text="ChickenTikka").grid(column=1, row=0, padx=20, pady=20)
        self.Pizza3=ttk.Button(self.PizzaTab, text="FajitaScilian").grid(column=2, row=0, padx=20, pady=20)
        self.Pizza4=ttk.Button(self.PizzaTab, text="SuperSupreame").grid(column=0, row=1, padx=20, pady=20)
        self.Pizza5 = ttk.Button(self.PizzaTab, text="Cheese Lover").grid(column=1, row=1, padx=20, pady=20)
        self.Pizza6 = ttk.Button(self.PizzaTab, text="VegieLover").grid(column=2, row=1, padx=20, pady=20)
        self.Pizza7 = ttk.Button(self.PizzaTab, text="ChickenSupreame").grid(column=0, row=2, padx=20, pady=20)
        self.Pizza8 = ttk.Button(self.PizzaTab, text="BeepSupreame").grid(column=1, row=2, padx=20, pady=20)
        self.Pizza9 = ttk.Button(self.PizzaTab, text="Cheese and Peproni").grid(column=2, row=2, padx=20, pady=20)
        self.Pizza10 = ttk.Button(self.PizzaTab, text="Creamy Tikka").grid(column=0, row=3, padx=20, pady=20)

#       Salad Buttons
        self.Salad1 = ttk.Button(self.SaladTab, text="Salad").grid(column=2, row=0, padx=20, pady=20)

#       MainMenu Buttons
        self.Pizza1 = ttk.Button(self.MenuTab, text="ChickenFajita").grid(column=0, row=0, padx=20, pady=20)
        self.Pizza2 = ttk.Button(self.MenuTab, text="ChickenTikka").grid(column=1, row=0, padx=20, pady=20)
        self.Pizza3 = ttk.Button(self.MenuTab, text="FajitaScilian").grid(column=2, row=0, padx=20, pady=20)
        self.Pizza4 = ttk.Button(self.MenuTab, text="SuperSupreame").grid(column=0, row=1, padx=20, pady=20)
        self.Pizza5 = ttk.Button(self.MenuTab, text="Cheese Lover").grid(column=1, row=1, padx=20, pady=20)
        self.Pizza6 = ttk.Button(self.MenuTab, text="VegieLover").grid(column=2, row=1, padx=20, pady=20)
        self.Pizza7 = ttk.Button(self.MenuTab, text="ChickenSupreame").grid(column=0, row=2, padx=20, pady=20)
        self.Pizza8 = ttk.Button(self.MenuTab, text="BeepSupreame").grid(column=1, row=2, padx=20, pady=20)
        self.Pizza9 = ttk.Button(self.MenuTab, text="Cheese and Peproni").grid(column=2, row=2, padx=20, pady=20)
        self.Pizza10 = ttk.Button(self.MenuTab, text="Creamy Tikka").grid(column=0, row=3, padx=20, pady=20)

        self.Salad1 = ttk.Button(self.MenuTab,text="Salad").grid(column=1, row=3, padx=20, pady=20)

        self.Pasta1 = ttk.Button(self.MenuTab, text="Lasagane").grid(column=2, row=3, padx=20, pady=20)
        self.Pasta2 = ttk.Button(self.MenuTab, text="Pasta").grid(column=0, row=4, padx=20, pady=20)
        self.Deal1_ = {"Price": 349}
        self.deal1 = ttk.Button(self.MenuTab, text="Deal1")
        self.deal1.grid(column=2, row=7, padx=20, pady=20)
        self.deal12 = ttk.Button(self.MenuTab, text="Deal2").grid(column=1, row=4, padx=20, pady=20)
        self.deal13 = ttk.Button(self.MenuTab, text="Deal3").grid(column=2, row=4, padx=20, pady=20)
        self.deal14 = ttk.Button(self.MenuTab, text="Deal3").grid(column=0, row=5, padx=20, pady=20)
        self.deal15 = ttk.Button(self.MenuTab, text="Deal3").grid(column=1, row=5, padx=20, pady=20)

        self.sevenUp = ttk.Button(self.MenuTab, text="7Up").grid(column=2, row=5, padx=20, pady=20)
        self.Pepsi = ttk.Button(self.MenuTab, text="Pepsi").grid(column=0, row=6, padx=20, pady=20)
        self.Dew = ttk.Button(self.MenuTab, text="DEW").grid(column=1, row=6, padx=20, pady=20)
        self.AquaFina = ttk.Button(self.MenuTab, text="AquaFina").grid(column=2, row=6, padx=20, pady=20)
        self.Sprite = ttk.Button(self.MenuTab, text="Sprite").grid(column=0, row=7, padx=20, pady=20)
        self.Marinda = ttk.Button(self.MenuTab, text="Marinda").grid(column=1, row=7, padx=20, pady=20)

#       InsertForms-BUtton
        self.cashierName=ttk.Label(self.Insert_button_form,text="CashierName").grid(column=0,row=0)
        self.cashierID = ttk.Label(self.Insert_button_form, text="CashierID").grid(column=0,row=1)
        self.CashierEmail=ttk.Label(self.Insert_button_form,text="CashierEmail").grid(column=0,row=2)
        self.CashierEmailText=ttk.Label(self.Insert_button_form,text="\ttext_Email").grid(column=2,row=2)
        self.CashierIDText=ttk.Label(self.Insert_button_form,text="\ttext_ID").grid(column=2,row=1)
        self.CashierName=ttk.Label(self.Insert_button_form,text="\ttext_Name").grid(column=2,row=0)
        Qn=tk.IntVar()
        self.Quantity_Label=ttk.Label(self.Insert_button_form,text="\nQuantity").grid(column=0,row=16)
        self.Quantity_comboBox=ttk.Combobox(self.Insert_button_form,width=27,textvariable=Qn)
        self.Quantity_comboBox["values"]=(1,2,3,4,5,6,7,8,9,10)
        self.Quantity_comboBox.grid(column=2,row=16)
        Sn = tk.StringVar()
        self.Size_Label=ttk.Label(self.Insert_button_form,text="\nSize").grid(column=0,row=18)
        self.Size_ComboBox=ttk.Combobox(self.Insert_button_form,width=27,textvariable=Sn)
        self.Size_ComboBox["values"]=("Small","Large","Pan Pizza","Regular","Jumbo")
        self.Size_ComboBox.grid(column=2,row=18)
        self.RecipetButton=ttk.Button(self.Insert_button_form,text="Reciept").grid(column=0,row=27,columnspan=5,rowspan=5)
#   BottomButtons
        self.PayButton=ttk.Button(self.Bottom_form,text="Pay").pack(side=tk.LEFT,padx=20,pady=20)
        self.Total_Text=ttk.Label(self.Bottom_form,text="$ ").pack(side=tk.LEFT,padx=20,pady=20)
        self.CancelButton=ttk.Button(self.Bottom_form,text="Cancel Order").pack(side=tk.RIGHT,padx=20,pady=20)
        self.ChangeButton=ttk.Button(self.Bottom_form,text="Change Order").pack(side=tk.RIGHT,padx=20,pady=20)
        self.LogOutButton=ttk.Button(self.Bottom_form,text="LogOut").pack(side=tk.RIGHT,padx=20,pady=20)
#   RecipetView
        self.Reciept_text=tk.Text(self.Reciept_form,height=31,width=50)
        self.Reciept_text.grid(column=0,row=0)
        self.Reciept_text.insert(tk.END,"\t\t\tHelloWord\t\t\t\t")

    def InsertDeal(self,deal_no):
        pass





if __name__=="__main__":
    root=tk.Tk()
    root.title("POS SYSTEM")
    root.geometry("1300x700")
    obj=Main_Menu(root)
    root.mainloop()