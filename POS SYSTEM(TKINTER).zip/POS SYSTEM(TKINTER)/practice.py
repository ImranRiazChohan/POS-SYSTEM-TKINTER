from tkinter import ttk
import tkinter as tk

root=tk.Tk()

root.mainloop()
