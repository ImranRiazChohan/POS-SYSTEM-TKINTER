import tkinter as tk
from tkinter import ttk

class ManagerPage:
    def __init__(self,root):
        self.root=root
        self.Main_frame=ttk.Frame(self.root,relief="solid")
        self.Bottom_frame=ttk.Frame(self.Main_frame,relief="solid")
        self.Top_frame = ttk.Frame(self.Main_frame, relief="solid")
        self.Left_frame = ttk.Frame(self.Main_frame, relief="solid")
        self.Right_frame = ttk.Frame(self.Main_frame, relief="solid")

        # self.employee_button=ttk.Button(self.Left_frame).pack(side=tk.TOP)
        # self.Sale_information_buttom=ttk.Button(self.Left_frame).pack(side=tk.BOTTOM)

        self.Update_button=ttk.Button (self.Bottom_frame)
        self.Delete_button=ttk.Button(self.Bottom_frame)
        self.Insert_button = ttk.Button(self.Bottom_frame)

if __name__=="__main__":
    root=tk.Tk()
    obj=ManagerPage(root)
    root.geometry("1000x1000")
    root.mainloop()